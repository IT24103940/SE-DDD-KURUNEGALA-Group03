// RoleName.java
package Group3.demo.Entity.enums;
public enum RoleName {
    ADMIN_OFFICER, IT_TECHNICIAN, MARKETING_EXECUTIVE, CUSTOMER_SUPPORT,
    FINANCE_ASSISTANT, SALES_MANAGER, CUSTOMER
}