// PromotionEventType.java
package Group3.demo.Entity.enums;
public enum PromotionEventType { VIEW, CLICK }