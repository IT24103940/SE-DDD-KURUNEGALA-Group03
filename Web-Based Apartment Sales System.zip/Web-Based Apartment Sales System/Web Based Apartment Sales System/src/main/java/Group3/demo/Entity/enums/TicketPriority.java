// TicketPriority.java
package Group3.demo.Entity.enums;
public enum TicketPriority { LOW, MEDIUM, HIGH }