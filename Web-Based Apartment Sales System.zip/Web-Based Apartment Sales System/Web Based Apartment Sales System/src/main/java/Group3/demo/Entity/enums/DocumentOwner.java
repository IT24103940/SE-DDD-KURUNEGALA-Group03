package Group3.demo.Entity.enums;

public enum DocumentOwner {
    SALES_ORDER,
    INVOICE
}

