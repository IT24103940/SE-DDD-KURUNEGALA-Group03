// TicketStatus.java
package Group3.demo.Entity.enums;
public enum TicketStatus { OPEN, IN_PROGRESS, RESOLVED, CLOSED }