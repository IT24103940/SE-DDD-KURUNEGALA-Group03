package Group3.demo.Entity.enums;

public enum PaymentPlan {
    FULL,
    HALF
}

