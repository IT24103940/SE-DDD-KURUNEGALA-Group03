// LeadStatus.java
package Group3.demo.Entity.enums;
public enum LeadStatus { NEW, CONTACTED, QUALIFIED, WON, LOST }