package Group3.demo.Repository;

import Group3.demo.Entity.Refund;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RefundRepository extends JpaRepository<Refund, Integer> { }