package Group3.demo.Entity.enums;

public enum DocumentType {
    CONTRACT,
    RECEIPT,
    KYC,
    OTHER
}

