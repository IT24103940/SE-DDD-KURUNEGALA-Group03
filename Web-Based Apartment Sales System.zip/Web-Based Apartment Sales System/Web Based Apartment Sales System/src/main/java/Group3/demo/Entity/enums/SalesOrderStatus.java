// SalesOrderStatus.java
package Group3.demo.Entity.enums;
public enum SalesOrderStatus { PENDING, COMPLETED, CANCELED }