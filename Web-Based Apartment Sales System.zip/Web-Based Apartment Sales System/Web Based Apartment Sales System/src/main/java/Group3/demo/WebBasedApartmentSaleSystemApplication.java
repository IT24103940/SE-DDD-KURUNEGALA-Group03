package Group3.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebBasedApartmentSaleSystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(WebBasedApartmentSaleSystemApplication.class, args);
	}
}