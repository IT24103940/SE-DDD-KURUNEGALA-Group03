// PaymentMethod.java
package Group3.demo.Entity.enums;
public enum PaymentMethod { CASH, CARD, TRANSFER }