// LogLevel.java
package Group3.demo.Entity.enums;
public enum LogLevel { INFO, WARN, ERROR }